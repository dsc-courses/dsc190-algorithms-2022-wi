
class OnlineMedian:


    def insert(self, key):
        ...

    def median(self):
        ...

