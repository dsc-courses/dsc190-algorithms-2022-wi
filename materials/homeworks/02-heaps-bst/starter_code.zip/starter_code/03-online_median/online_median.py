
class OnlineMedian:


    def insert(self, key):
        """Insert a key into the collection."""
        ...

    def median(self):
        """Return a median of the collection.

        If the collection is empty, returns nan.

        Example
        -------

        >>> om = OnlineMedian()
        >>> om.median()
        nan
        >>> om.insert(30)
        >>> om.insert(10)
        >>> om.insert(-20)
        >>> om.median()
        10

        """
        ...

