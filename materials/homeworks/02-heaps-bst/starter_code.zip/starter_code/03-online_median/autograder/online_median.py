class OnlineMedian:

    def __init__(self):
        ...

    def insert(self, key):
        """Insert a new element into the collection."""
        ...

    def median(self):
        """Return the median."""
        ...
