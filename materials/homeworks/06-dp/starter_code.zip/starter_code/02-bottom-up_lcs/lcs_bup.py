def lcs_bup(text1, text2):
    """Find the length of the longest common substring between `a` and `b`.

    Your code should take a bottom-up dynamic programming approach. You may add
    additional optional arguments to this function or create helper functions.

    Parameters
    ----------
    a, b (str)
        The strings to be checked for common substrings.

    Returns
    -------
    int
        The length of the longest common substring between `a` and `b`. Can be zero.

    Example
    -------
    >>> lcs_bup("cal berkeley", "cow birkley")
    8
    >>> lcs_bup("uc san diego", "you see sandy eggo waffles")
    9

    """
    ...
