def lcs_bup(text1, text2):
    """Find the length of the longest common substring between `a` and `b`.

    Your code should take a bottom-up dynamic programming approach. You may add
    additional optional arguments to this function or create helper functions.

    Parameters
    ----------
    a, b (str)
        The strings to be checked for common substrings.

    Returns
    -------
    int
        The length of the longest common substring between `a` and `b`. Can be zero.

    Example
    -------
    >>> lcs_bup("cal berkeley", "cow birkley")
    8
    >>> lcs_bup("uc san diego", "you see sandy eggo waffles")
    9

    """
    dp = [0]*(len(text1) + 1) #the dp table assumes first char is empty string ""
    
    for j in range(len(text2)):
        dpn = [0]
        for i in range(len(text1)):
            if text1[i] == text2[j]:
                dpn.append(dp[i] + 1)
            else:
                dpn.append(max(dpn[i], dp[i + 1]))
        dp = dpn
    return dp[-1]
