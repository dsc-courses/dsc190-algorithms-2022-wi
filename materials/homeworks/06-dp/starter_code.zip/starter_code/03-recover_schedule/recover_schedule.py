def recover_schedule(cache, next_activity):
    """Return the indices of the activities that should be selected.

    You may assume that the activities are labeled in increasing order of their
    start time. In the case that more than one schedule is optimal, return an
    arbitrary one.

    Parameters
    ----------
    cache : List[float]
        A list such that cache[i] is the largest total weight of any valid
        schedule that consists of elements from the set {i, i+1, i+2, ..., n-1}.
        If there are n activities, `cache` should have n + 1 elements, with the last
        element being a dummy element equal to zero.
    next_activity : List[int]
        A list of integers such that next_activity[i] is the index of the next
        activity whose start time is >= activity i's end time.

    Returns
    -------
    List[int]
        A list of the activities containing in an optimal schedule.

    Example
    -------
    >>> cache = [50, 50, 30, 20, 20, 0]
    >>> next_activity = [2, 3, 4, 5, 5]
    >>> recover_schedule(cache, next_activity)
    [1, 4]

    """
    ...
