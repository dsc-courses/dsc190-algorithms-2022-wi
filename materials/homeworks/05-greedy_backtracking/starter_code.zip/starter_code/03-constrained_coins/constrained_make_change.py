VALUES = (25, 10, 5, 1)


def constrained_make_change(t, coins):
    """Compute the number of ways to make change, given a set number of each coin.

    Examples
    --------
    >>> constrained_make_change(11, [1, 1, 2, 5])
    2
    >>> constrained_make_change(11, [99, 99, 99, 99])
    4
    >>> constrained_make_change(25, [2, 0, 0, 25])
    2

    """
    ...
