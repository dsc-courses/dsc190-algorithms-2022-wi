>>> multiple_rabin_karp("this is a test. testing.", ["this", "test"])
[[0], [10, 16]]
