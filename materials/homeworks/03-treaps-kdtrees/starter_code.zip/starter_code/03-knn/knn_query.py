import numpy as np

import kd_tree


def knn_query(node: kd_tree.KDInternalNode, p: np.ndarray, k: int=1):
    """Perform a k-nearest neighbor query on a k-d tree.

    Parameters
    ----------
    node: KDInternalNode
        The node whose subtree should be searched.
    p: np.ndarray
        The point to query.
    k: int
        The number of neighbors to return. Default: 1

    Returns
    -------
    np.ndarray
        An array of distances to the k neighbors in sorted order.
    np.ndarray
        A k-by-d ndarray containing the k nearest neighbors in order of their
        distance to the query point.

    Note
    ----
    Ties are broken arbitrarily. If k is less than the number of points in the
    tree overall, then all points are returned.

    Example
    -------
    >>> data = np.array([
    ...     [1, 2, 3],
    ...     [4, 2, 1],
    ...     [1, 1, 1],
    ...     [7, 5, 5],
    ...     [3, 2, 0]
    ... ])
    >>> p = np.array([1, 1, 0])
    >>> root = kd_tree.build_kd_tree(data) # implemented in lecture
    >>> distances, points = knn_query(root, p, k=2)
    >>> distances[0]
    1.0
    >>> np.isclose(distances[1], 2.236, atol=1e-3)
    True
    >>> points
    array([[1, 1, 1],
           [3, 2, 0]])

    """
    ...
